#!/bin/bash
rvm install ruby-2.4.0
#Installs specific version to match dependencies.
source ~/.rvm/scripts/rvm
rvm use ruby-2.4.0
#These set the path and version. They don't seem to last beyond the current shell session, so they're also part of the reboot script.
gem install rails
#gem install comes with ruby and is the best way to install rails.
sudo wget ftp://ftp.freetds.org/pub/freetds/stable/freetds-1.00.21.tar.gz
#freetds is required for tiny tds (a sql server adapter).
tar -xzf freetds-1.00.21.tar.gz
cd freetds-1.00.21
./configure --prefix=/usr/local --with-tdsver=7.3
make
sudo make install
#These lines are directly from https://github.com/rails-sqlserver/tiny_tds for installing Tiny TDS.
cd ~
cd RHapi
bundle
#This is the standard rails command to download the gems listed in the gemfile.
rails s 
#boots the rails server, the ampersand keeps it up in the background.
