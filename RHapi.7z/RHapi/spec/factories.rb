FactoryGirl.define do
  factory :problem do
    term('Asthma')
    source_lang('ENG')
    output_lang('ENG')
  end
end
