#!/bin/bash
source ~/.profile
#Sets route
nvm install 6.11.3
#Installs specific version.
gpg --keyserver hkp://keys.gnupg.net --recv-keys 409B6B1796C275462A1703113804BB82D39DC0E3 7D2BAF1CF37B13E2069D6956105BD0E739499BDB
#GPG security key for RVM. Refer to https://rvm.io/ for more info.
\curl -sSL https://get.rvm.io -o rvm.sh
#Prep rvm for installation.
cat rvm.sh | bash -s stable
#Installs rvm. Note that you must logout and log back in to complete installation.
