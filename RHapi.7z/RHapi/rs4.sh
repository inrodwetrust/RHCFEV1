#! /bin/bash
source ~/.rvm/scripts/rvm
rvm use ruby-2.4.0
cd RHapi
shutup
rails s

#This script is to be run when reentering the web shell after it has crashed.
