#!/bin/bash

sudo apt-get update
#This line makes sure apt is up to date. You will have had to give sudo permissions to the user.
yes Y | sudo apt-get install build-essential libssl-dev libc6-dev libpq-dev
#These help set the environment and enable later downloads of gems.
curl -sL https://raw.githubusercontent.com/creationix/nvm/v0.32.0/install.sh -o install_nvm.sh
#This preps node version manager.
bash install_nvm.sh
#Installs node version manager. Note that you must now logout to complete the installation.
