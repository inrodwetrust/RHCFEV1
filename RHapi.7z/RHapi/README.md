# RHapi
An API which queries Recentia Health database

#### Description
A Ruby on Rails API connected to an MS SQLServer database. The endpoints are build on database custom stored procedures.
## Access API
### Reboot App on VM
  * Enter VM IP address in browser. If you have already created a username and password and RHapi is currently on the VM (which should be the case but you can double check with an `$ ls` in the second step) skip the next step.
  * In Webmin log in using root as the username (password set by Brian) and create a new user under the Users and Groups icon. The only necessary fields are Username and Password selecting the "Normal password" option.
  * Login to Web Shell with your new username and password. `$ ls` will list RHapi if it has been installed. If it is installed, go to the next step, if it has not been installed, proceed to [Install App on VM](#install-app-on-vm) section of this README.
  * `$ ./rs4.sh`

The app is successfully served when the following appears in the terminal.
`* Listening on tcp://0.0.0.0:5000` `Use Ctrl-C to stop`

### Paths
  For both endpoints if a required parameter is not listed or assigned a value or any of the records do not exist, an empty array will be returned. If a parameter value is two words the proper format is a space between words. The browser will add %20 where necessary.
  * Get Chart:
  IP-ADDRESS:5000/charts?domain=ProblemLists&patient_id=1&physician_id=1

  Replace "ProblemsList" & "1" with desired values which must match database values including capitalization to customize search. These are the minimum parameters to get a response. The following parameters are also available with the stored procedure equivalent.
    * domain = Domain
    * record_id = RecordID
    * patient_id = PatientID
    * physician_id = PhysicianID
    * sort_field = SortField
    * sort_order = SortOrder
    * row_offset = RowOffset
    * rows_in_subset = RowsInSubset
    * input_language = InputLanguage
    * output_language = OutputLanguage


  * Get Problem:
   IP-ADDRESS:5000/problems?term=thyroiditis&input_language=ENG&output_language=ENG

  Replace "thyroiditis" and "ENG" with the desired values to customize search.

### Install App on VM
  * Create user
    * Enter VM IP address in browser.
    * In Webmin log in using root as the username (password set by Brian) and create a new user under the Users and Groups icon. The only necessary fields are Username and Password selecting the "Normal password" option.
  * Add RHapi and credentials to your machine in order to transfer it to the VM
    * `$ git clone https://git-codecommit.us-west-2.amazonaws.com/v1/repos/RHapi`
    * `$ cd RHapi`
    * `$ touch .env` The .env file is one that will be ignored if the app is pushed to a remote repository.
    * Open app with text editor and add the following 3 variables to .env file. These are database credentials. Use this example format: HIDDEN_USERNAME=johndoe.
    HIDDEN_USERNAME=
    HIDDEN_PASSWORD=  
    HIDDEN_HOST=
    * In order to bypass the .env steps replace variables in database.yml file with equivalent values keeping in mind that they will show up in the remote repository if the app gets pushed to that repo.
  * Upload app with Filezilla
    * Host: VM IP address
    * Username and password are those established in the first step
    * Port: 22
    * Move RHapi to your VM user folder, which will have the name you just established in Webmin.
    * Move rs1.sh, rs2.sh, rs3.sh and rsreboot.sh out of RHapi and to the same VM user folder.
    * In Web Shell, `$ ls` will confirm presence of these files in home directory. If it is not listed, retry Filezilla and proceed once RHapi is listed.
  * Set up sudo privileges for user
    * Log out of Web Shell and back in as root with password set by Brian
    * `# apt-get install sudo`
    * Once # and flashing cursor appear, `# adduser USERNAME-CREATED-IN-WEBMIN sudo` and proceed when terminal says "Done."
  * Set up environment using scripts
    * Log out of Web Shell and back in as recently created user
    * `$ chmod a+x rs*.sh`
    * `$ ./rs1.sh`
    * Enter password when prompted and wait for $ to appear before continuing
    * Log out of Web Shell and back in as user
    * `$ ./rs2.sh`
    * Wait for $ to appear before continuing
    * Log out of Web Shell and back in as user
    * `$ ./rs3.sh`
    * Enter password when prompted, this will happen twice for this script. It takes a while to run, so some patience is recommended and this is a good time to go grab a juicebox.

The app is successfully served when the following appears in the terminal.`* Listening on tcp://0.0.0.0:5000` `Use Ctrl-C to stop`

Done! Navigate to desired endpoint listed in Paths.

## Troubleshooting
If the server goes down following [Reboot App on VM](#reboot-app-on-vm) section will be required to return data.

If there is no response from the IP address or there is an error that lists failure to connect to the host address, double check that .env file contains the proper credentials. If that is in place and correct check that the server is still running.

If a script fails, they were built with information gleaned from the following sources:
* https://rvm.io/rvm/install
* https://www.digitalocean.com/community/tutorials/how-to-install-ruby-on-rails-with-rvm-on-debian-8
* https://github.com/rails-sqlserver/tiny_tds
* Brian's brain

## Technologies Used
* [Ruby](https://www.ruby-lang.org/en/downloads/)
* [Rails](http://rubyonrails.org/)
* [Dbeaver](https://dbeaver.jkiss.org/)
* [AWS CodeCommit](https://aws.amazon.com/codecommit/)
* [Tiny TDS](https://github.com/rails-sqlhserver/tiny_tds)
* [ActiveRecord SQLServer Adapter](https://github.com/rails-sqlserver/activerecord-sqlserver-adapter)
* [Shutup](https://github.com/lorenzosinisi/shutup)

## Authors
Jin Camou, Susha Dore, Ben Williams
